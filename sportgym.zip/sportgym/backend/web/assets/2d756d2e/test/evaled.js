window.externalScriptLoaded()

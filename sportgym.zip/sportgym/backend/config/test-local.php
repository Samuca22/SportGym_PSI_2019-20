<?php
return [
    'components' => [
        'db' => [
            'dsn' => 'mysql:host=localhost;dbname=sportgymdb_test',
        ],
    ],
];
